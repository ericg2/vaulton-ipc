//! [`StorageManager`] — unified cache for rustic repositories, VFS operators,
//! and raw data-layer operators.

use crate::core::{PointHealth, VfsError, VfsPoint, VfsResult, VfsUser};
use crate::ipc::PointStatusEvent;
use dashmap::DashMap;
use log::{error, info};
use crate::db::DbManager;
use crate::progress::RusticProgressBars;
use crate::utils;
use async_trait::async_trait;
use crossbeam_channel::Sender;
use moka::sync::Cache;
use opendal_core::Operator;
use opendal_vfs::layers::quota::{QuotaLayer, QuotaState};
use opendal_vfs::layers::read_only::ReadOnlyLayer;
use opendal_vfs::layers::vfs::VfsBuilder;
use rustic_backend::opendal::*;
use rustic_backend::{BackendBuilder, BackendOptions};
use rustic_core::{
    ConfigOptions, Credentials, ErrorKind, IndexedFullStatus, KeyOptions, OpenStatus, Repository,
    RepositoryOptions, RusticError, RusticResult,
};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::fmt::Debug;
use std::sync::Arc;
use std::time::Duration;
use unftp_core::storage::StorageBackend;
use uuid::Uuid;
use crate::ipc::ipc_event::Data;

pub type RepoNoIndex = Repository<OpenStatus>;
pub type RepoIndexed = Repository<IndexedFullStatus>;

/// Unified storage interface covering three access patterns:
///
/// - **Indexed repositories** — full rustic repos used for backup/restore.
/// - **VFS operators** — OpenDAL [`Operator`]s backed by a rustic snapshot
///   tree for filesystem-style reads over repo contents.
/// - **Data-layer operators** — OpenDAL [`Operator`]s for raw scheme-level
///   storage (S3, local disk, etc.), independent of any rustic repo.
#[async_trait]
pub trait StorageSystem: Send + Sync + 'static {
    /// Returns a cached, indexed rustic repository for the given source.
    ///
    /// Opens the repository on first access; subsequent calls for the same
    /// source return the cached handle until the TTI window expires.
    async fn get_repo(&self, src: &RepoSource) -> RusticResult<Arc<RepoIndexed>>;

    /// Opens a fresh indexed repository tied to a background job, forwarding
    /// progress events over `tx`.
    ///
    /// Results are **not** cached — each call produces a new handle so that
    /// progress reporting is scoped to the job lifetime.
    ///
    /// `allow_init` controls whether a *missing* repository is created. It is
    /// only ever `true` for backups; restore/check/forget must fail loudly
    /// instead of silently creating an empty repo.
    async fn get_repo_job(
        &self,
        src: &RepoSource,
        op: opendal_core::blocking::Operator,
        job_id: Uuid,
        tx: Sender<Data>,
        allow_init: bool,
    ) -> RusticResult<RepoIndexed>;

    /// Creates a VFS for the given user.
    async fn get_vfs(&self, user: &VfsUser) -> VfsResult<Operator>;

    /// Removes the VFS instance for a user (healthy and degraded caches).
    fn invalidate_vfs(&self, user: &VfsUser);

    /// Last recorded load state of a point, or `None` if never loaded.
    fn point_health(&self, id: &Uuid) -> Option<PointHealth>;

    /// Builds an operator for a single named data point belonging to `user`,
    /// applying the same read-only/quota layering as [`get_vfs`](Self::get_vfs)
    /// applies to that point's mount.
    ///
    /// Intended for backup/restore jobs, which read/write a data point's
    /// backend directly (via `OpenDALSource::new`) rather than through the
    /// user's mounted VFS tree — without this, those jobs would bypass quota
    /// enforcement and the point's read-only flag entirely.
    fn get_data_operator(
        &self,
        user: &VfsUser,
        point: &VfsPoint,
    ) -> VfsResult<opendal_core::blocking::Operator>;
}

/// Identifies a rustic repository by its storage scheme and decryption
/// password.
///
/// Used as the cache key for both [`get_repo`](StorageSystem::get_repo) and
/// [`get_vfs_operator`](StorageSystem::get_vfs_operator).
#[derive(Hash, Clone, Eq, PartialEq, Debug, Serialize, Deserialize)]
pub struct RepoSource {
    /// The OpenDAL scheme that locates the repository.
    pub scheme: String,
    pub config: BTreeMap<String, String>,
    pub password: String,
}

/// Concrete implementation of [`StorageSystem`] backed by three
/// [`moka`] caches with a shared time-to-idle eviction policy.
///
/// | Cache      | Key          | Value              | Purpose                |
/// |------------|--------------|--------------------|------------------------|
/// | `repos`    | `RepoSource` | `Arc<RepoIndexed>` | Indexed rustic repos   |
/// | `vfs_ops`  | `VfsUser`    | `Operator`         | Per-user VFS operators |
#[derive(Clone)]
pub struct StorageManager {
    repos: Cache<RepoSource, Arc<RepoIndexed>>,
    vfs_ops: Cache<VfsUser, Operator>,
    /// VFS trees built while at least one point failed. Short TTL so failed
    /// points are retried soon without re-initializing on every request.
    degraded_ops: Cache<VfsUser, Operator>,
    health: Arc<DashMap<Uuid, PointHealth>>,
    events: Sender<Data>,
    pub(crate) state: QuotaState,
}

/// How long a partially-failed VFS is served before points are retried.
const DEGRADED_TTL: Duration = Duration::from_secs(30);

fn repo_err(msg: impl Into<String>) -> RusticError {
    let msg = msg.into();
    RusticError::with_source(ErrorKind::Backend, msg.clone(), std::io::Error::other(msg))
}

/// A rustic repository exists iff its `config` file does. Any error other
/// than NotFound (network, auth, bad config) is returned as-is instead of
/// being mistaken for "repo missing" and triggering a bogus `init`.
fn repo_exists(op: &opendal_core::blocking::Operator) -> RusticResult<bool> {
    match op.stat("config") {
        Ok(_) => Ok(true),
        Err(e) if e.kind() == opendal_core::ErrorKind::NotFound => Ok(false),
        Err(e) => Err(RusticError::with_source(
            ErrorKind::Backend,
            "Cannot reach repository storage",
            e,
        )),
    }
}

impl StorageManager {
    /// Creates a new [`StorageManager`] whose caches evict entries after
    /// `tti` of inactivity.
    pub fn new(db: Arc<DbManager>, tti: Duration, events: Sender<Data>) -> Self {
        Self {
            repos: Cache::builder()
                .time_to_idle(tti)
                .max_capacity(1000)
                .build(),

            vfs_ops: Cache::builder()
                .time_to_idle(tti)
                .max_capacity(1000)
                .build(),

            degraded_ops: Cache::builder()
                .time_to_live(DEGRADED_TTL)
                .max_capacity(1000)
                .build(),

            health: Arc::new(DashMap::new()),
            events,
            state: QuotaState::new(db.clone()),
        }
    }

    /// Records a point's health; logs and emits a `PointStatusEvent` only on change.
    fn set_health(&self, user: &VfsUser, point: &VfsPoint, new: PointHealth) {
        let changed = self.health.insert(point.id, new.clone()).as_ref() != Some(&new);
        if !changed {
            return;
        }
        let (health, err) = match &new {
            PointHealth::Healthy => {
                info!("point '{}' of user '{}' loaded", point.name, user.username);
                (crate::ipc::PointHealth::Healthy, String::new())
            }
            PointHealth::Failed(e) => {
                error!("point '{}' of user '{}' failed: {e}", point.name, user.username);
                (crate::ipc::PointHealth::Failed, e.clone())
            }
        };
        let _ = self.events.send(Data::PointStatus(PointStatusEvent {
            user: user.username.clone(),
            point_id: point.id.to_string(),
            point_name: point.name.clone(),
            health: health as i32,
            error: err,
            time: crate::proto_stamp(rustic_core::jiff::Timestamp::now()),
        }));
    }

    // ── Repository helpers ────────────────────────────────────────────────

    fn probe(src: &RepoSource) -> RusticResult<opendal_core::blocking::Operator> {
        let op = Operator::via_iter(&src.scheme, src.config.clone())
            .and_then(opendal_core::blocking::Operator::new)
            .map_err(|e| RusticError::with_source(ErrorKind::Backend, "Invalid storage config", e))?;
        Ok(op)
    }

    /// Opens (or, when `allow_init`, creates) a repository **without** loading
    /// its index. Cheap enough for VFS builds and validates the password.
    fn ensure_repo(&self, src: &RepoSource, allow_init: bool) -> RusticResult<()> {
        let exists = repo_exists(&Self::probe(src)?)?;
        let creds = Credentials::password(&src.password);
        let config = OpenDALConfig::default()
            .scheme(src.scheme.clone())
            .options(src.config.clone().into_iter().collect::<HashMap<_, _>>());
        let backend = BackendOptions::default().with_repo(&config).to_backends()?;
        let repo = Repository::new(&RepositoryOptions::default(), &backend)?;
        if exists {
            repo.open(&creds)?;
        } else if allow_init {
            info!("initializing new repository ({})", src.scheme);
            repo.init(&creds, &KeyOptions::default(), &ConfigOptions::default())?;
        } else {
            return Err(repo_err("repository does not exist (and this point is read-only)"));
        }
        Ok(())
    }

    /// Opens an existing repository, creating it only if `allow_init`.
    fn get_raw_repo(&self, src: &RepoSource, allow_init: bool) -> RusticResult<RepoIndexed> {
        self.ensure_repo(src, allow_init)?;
        let creds = Credentials::password(&src.password);
        let config = OpenDALConfig::default()
            .scheme(src.scheme.clone())
            .options(src.config.clone().into_iter().collect::<HashMap<_, _>>());
        let backend = BackendOptions::default().with_repo(&config).to_backends()?;
        Repository::new(&RepositoryOptions::default(), &backend)?
            .open(&creds)?
            .to_indexed()
    }

    /// Job-scoped variant with progress events over `tx`.
    fn create_for_job(
        &self,
        src: &RepoSource,
        op: opendal_core::blocking::Operator,
        job_id: Uuid,
        tx: Sender<Data>,
        allow_init: bool,
    ) -> RusticResult<RepoIndexed> {
        let exists = repo_exists(&op)?;
        let creds = Credentials::password(&src.password);
        let backend = OpenDALSource::new(op).to_backends()?;
        let pb = RusticProgressBars::new(job_id, tx);
        let repo = Repository::new_with_progress(&RepositoryOptions::default(), &backend, pb)?;
        if exists {
            repo.open(&creds)?.to_indexed()
        } else if allow_init {
            repo.init(&creds, &KeyOptions::default(), &ConfigOptions::default())?
                .to_indexed()
        } else {
            Err(repo_err("repository does not exist"))
        }
    }

    /// Builds a single-point operator with the read-only/quota policy from
    /// `point` applied directly as OpenDAL layers.
    ///
    /// This is the one place read-only and quota layering for data points is
    /// wired up: it's reused both when composing a user's full VFS tree and
    /// when a backup/restore job needs to touch a single point's backend
    /// directly. `VfsBuilder` refuses to mount at its virtual root `"/"`, so
    /// this applies [`ReadOnlyLayer`]/[`QuotaLayer`] straight to the raw
    /// operator instead of routing through a single-mount `VfsBuilder`.
    fn point_operator(&self, user: &VfsUser, point: &VfsPoint) -> VfsResult<Operator> {
        let mut op = Operator::via_iter(&point.scheme, point.config.clone())?;

        if point.read_only {
            op = op.layer(ReadOnlyLayer);
        } else if let Some(max) = point.max_bytes {
            // Local/fs-backed *data* points are quota-checked against
            // their true on-disk footprint (`utils::dir_size`) directly by
            // the IPC write handlers and by `FtpServer::put` in `ftp.rs`,
            // instead of through this incremental write-counter layer.
            // Skip it here so the two accounting mechanisms don't both
            // apply (and disagree) for the same point — see
            // `utils::dir_size` for why the counter isn't trustworthy for
            // data points any more.
            //
            // Repo points are excluded from that switch even when they're
            // also local/fs-backed: their content is written by rustic
            // during backup jobs (`get_data_operator`, not the
            // `Vfs_OpenWrite`/`Vfs_WriteAt` handles or `Vfs_WriteFile`), so
            // there's no code path that would ever perform a `dir_size`
            // check for them — leaving the counter attached here is the
            // only enforcement they get.
            if point.is_repo || !utils::is_local_scheme(&point.scheme) {
                op = op.layer(QuotaLayer::new(
                    self.state.clone(),
                    utils::quota_id(&user.username, &point.id),
                    max,
                ));
            }
        }

        Ok(op)
    }

    /// Builds one mount. Any failure here only affects this point.
    fn build_mount(&self, user: &VfsUser, point: &VfsPoint) -> VfsResult<(String, Operator)> {
        if !point.is_repo {
            let op = self.point_operator(user, point)?;
            return Ok((utils::data_mount_path(&point.name), op));
        }

        let pass = point.repo_password.clone().ok_or(VfsError::RepoPasswordMissing)?;
        let src = RepoSource {
            scheme: point.scheme.clone(),
            config: point.config.clone(),
            password: pass.clone(),
        };
        // Read-only repo points must never be created implicitly.
        self.ensure_repo(&src, !point.read_only)
            .map_err(|e| VfsError::Storage(Box::new(e)))?;

        let config = OpenDALConfig::default()
            .scheme(point.scheme.clone())
            .options(point.config.clone().into_iter().collect::<HashMap<_, _>>());
        let op = Operator::from_config(RusticVfsConfig {
            options: RepositoryOptions::default(),
            backend: BackendOptions::default().with_repo(&config),
            credentials: Some(Credentials::password(&pass)),
            refresh_interval: Some(Duration::from_mins(2)),
        })?;
        Ok((utils::repo_mount_path(&point.name), op))
    }

    /// Builds the user's VFS. A point that fails to load is recorded, logged
    /// and skipped — it never prevents the user's other points from mounting.
    /// Returns `(operator, degraded)`.
    fn create_for_vfs(&self, user: &VfsUser) -> VfsResult<(Operator, bool)> {
        let mut vfs = VfsBuilder::new(self.state.clone());
        let mut degraded = false;
        for point in user.points.iter() {
            match self.build_mount(user, point) {
                Ok((path, op)) => {
                    // Repo mounts are always read-only inside the VFS tree;
                    // `point.read_only` gates backup/forget jobs instead.
                    vfs = if point.is_repo {
                        vfs.mount(path, op).read_only()
                    } else {
                        vfs.mount(path, op)
                    };
                    self.set_health(user, point, PointHealth::Healthy);
                }
                Err(e) => {
                    degraded = true;
                    self.set_health(user, point, PointHealth::Failed(e.to_string()));
                }
            }
        }
        Ok((Operator::new(vfs)?, degraded))
    }
}

#[async_trait]
impl StorageSystem for StorageManager {
    async fn get_repo(&self, src: &RepoSource) -> RusticResult<Arc<RepoIndexed>> {
        if let Some(repo) = self.repos.get(src) {
            return Ok(repo);
        }
        // Concurrent misses may both open the repo; the second insert simply wins.
        let this = self.clone();
        let src = src.clone();
        tokio::task::spawn_blocking(move || {
            // check again inside — another task may have populated it while we waited
            if let Some(repo) = this.repos.get(&src) {
                return Ok(repo);
            }
            let repo = Arc::new(this.get_raw_repo(&src, false)?);
            this.repos.insert(src, repo.clone());
            Ok(repo)
        })
            .await
            .map_err(|e| RusticError::with_source(ErrorKind::Backend, "spawn_blocking panicked", e))?
    }

    async fn get_repo_job(
        &self,
        src: &RepoSource,
        operator: opendal_core::blocking::Operator,
        job_id: Uuid,
        tx: Sender<Data>,
        allow_init: bool,
    ) -> RusticResult<RepoIndexed> {
        let this = self.clone();
        let src = src.clone();
        tokio::task::spawn_blocking(move || {
            this.create_for_job(&src, operator, job_id, tx, allow_init)
        })
            .await
            .map_err(|e| RusticError::with_source(ErrorKind::Backend, "spawn_blocking panicked", e))?
    }

    async fn get_vfs(&self, user: &VfsUser) -> VfsResult<Operator> {
        if let Some(op) = self.vfs_ops.get(user).or_else(|| self.degraded_ops.get(user)) {
            return Ok(op);
        }

        let this = self.clone();
        let user = user.clone();
        tokio::task::spawn_blocking(move || {
            let (op, degraded) = this.create_for_vfs(&user)?;
            let cache = if degraded { &this.degraded_ops } else { &this.vfs_ops };
            cache.insert(user, op.clone());
            Ok(op)
        })
            .await
            .map_err(|e| VfsError::Internal(format!("spawn_blocking panicked: {e}")))?
    }

    fn invalidate_vfs(&self, user: &VfsUser) {
        self.vfs_ops.invalidate(user);
        self.degraded_ops.invalidate(user);
    }

    fn point_health(&self, id: &Uuid) -> Option<PointHealth> {
        self.health.get(id).map(|h| h.clone())
    }

    fn get_data_operator(
        &self,
        user: &VfsUser,
        point: &VfsPoint,
    ) -> VfsResult<opendal_core::blocking::Operator> {
        let op = self.point_operator(user, point)?;
        let x = opendal_core::blocking::Operator::new(op)?;
        Ok(x)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;

    async fn manager() -> StorageManager {
        let db = Arc::new(
            DbManager::open(":memory:")
                .await
                .expect("open in-memory db"),
        );
        StorageManager::new(db, Duration::from_secs(60), crossbeam_channel::unbounded().0)
    }

    fn memory_point(name: &str, read_only: bool, max_bytes: Option<u64>) -> VfsPoint {
        VfsPoint {
            id: Uuid::new_v4(),
            name: name.to_string(),
            max_bytes,
            read_only,
            scheme: "memory".into(),
            config: BTreeMap::new(),
            is_repo: false,
            repo_password: None,
        }
    }

    fn user_with(points: Vec<VfsPoint>) -> VfsUser {
        VfsUser {
            username: "alice".into(),
            password: "pw".into(),
            points,
        }
    }

    #[tokio::test]
    async fn read_only_point_operator_rejects_writes() {
        let mgr = manager().await;
        let point = memory_point("ro", true, None);
        let user = user_with(vec![point.clone()]);

        let op = mgr.point_operator(&user, &point).unwrap();
        let err = op.write("file.txt", b"hi".to_vec()).await.unwrap_err();
        assert_eq!(err.kind(), opendal_core::ErrorKind::PermissionDenied);
    }

    #[tokio::test]
    async fn read_only_point_operator_allows_reads() {
        let mgr = manager().await;

        // Write via a writable operator over the same backend config first,
        // since the read-only operator itself must never be able to write.
        let writable = memory_point("seed", false, None);
        let user = user_with(vec![writable.clone()]);
        let seed_op = mgr.point_operator(&user, &writable).unwrap();
        seed_op.write("file.txt", b"hi".to_vec()).await.unwrap();

        let data = seed_op.read("file.txt").await.unwrap();
        assert_eq!(data.to_vec(), b"hi");
    }

    #[tokio::test]
    async fn writable_point_operator_allows_writes() {
        let mgr = manager().await;
        let point = memory_point("rw", false, None);
        let user = user_with(vec![point.clone()]);

        let op = mgr.point_operator(&user, &point).unwrap();
        op.write("file.txt", b"hi".to_vec()).await.unwrap();
        let data = op.read("file.txt").await.unwrap();
        assert_eq!(data.to_vec(), b"hi");
    }

    #[tokio::test]
    async fn quota_enforced_on_point_operator() {
        let mgr = manager().await;
        let point = memory_point("quota", false, Some(4));
        let user = user_with(vec![point.clone()]);

        let op = mgr.point_operator(&user, &point).unwrap();
        op.write("small.txt", b"ab".to_vec()).await.unwrap();

        let err = op.write("big.txt", b"toolarge".to_vec()).await.unwrap_err();
        assert_eq!(err.kind(), opendal_core::ErrorKind::RateLimited);
    }

    #[tokio::test]
    async fn get_data_operator_applies_same_policy_as_point_operator() {
        let mgr = manager().await;
        let point = memory_point("ro", true, None);
        let user = user_with(vec![point.clone()]);

        let op = mgr.get_data_operator(&user, &point).unwrap();
        assert!(op.write("x", b"y".to_vec()).is_err());
    }

    #[tokio::test]
    async fn invalidate_vfs_evicts_cached_operator() {
        let mgr = manager().await;
        let user = user_with(vec![memory_point("d", false, None)]);

        let op1 = mgr.get_vfs(&user).await.unwrap();
        mgr.invalidate_vfs(&user);
        let op2 = mgr.get_vfs(&user).await.unwrap();

        // Both calls succeed; the important behavior under test is that
        // invalidation doesn't error and a fresh operator can be rebuilt.
        let _ = (op1, op2);
    }
}